LifeFlow map update package

Files:
- frontend/src/App.tsx (complete replacement, based on the supplied full App.tsx)
- frontend/src/api.ts (complete replacement; includes centre verification metadata)
- frontend/src/components/CentersMap.tsx (new Leaflet map component)
- backend/import_verified_centres.py (safe, repeatable centre-directory import)

Copy the frontend files into the matching paths in your Codespace. Copy the backend script to backend/import_verified_centres.py.
Then run the backend import script from the backend folder with the virtual environment active.

The importer deactivates the three fictional placeholder centres without deleting them, preserves donor/appointment foreign-key history, and adds six real directory entries. It adds a map coordinate only for Victoria Hospital Blood Bank, for which an OpenStreetMap blood-bank node coordinate was located. The other five entries remain in the directory without pins or distance calculations until their exact coordinates are verified.

Do not treat the existing demo inventory as live blood stock. Contact each centre directly to confirm donation services, hours, and current availability.
