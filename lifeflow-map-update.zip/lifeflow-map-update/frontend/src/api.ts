const API_BASE = "/api";

async function apiRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...options.headers },
  });
  if (!response.ok) {
    const error = await response.json().catch(() => null);
    throw new Error(error?.detail || `Request failed: ${response.status}`);
  }
  return response.json();
}

export interface GPSLocation { latitude: number; longitude: number; }

export const getCurrentLocation = (): Promise<GPSLocation> => new Promise((resolve, reject) => {
  if (!navigator.geolocation) {
    reject(new Error("GPS location is not supported by this browser."));
    return;
  }
  navigator.geolocation.getCurrentPosition(
    (position) => resolve({ latitude: position.coords.latitude, longitude: position.coords.longitude }),
    (error) => {
      switch (error.code) {
        case error.PERMISSION_DENIED: reject(new Error("Location permission denied. Please allow location access.")); break;
        case error.POSITION_UNAVAILABLE: reject(new Error("Your current location is unavailable.")); break;
        case error.TIMEOUT: reject(new Error("Location request timed out. Please try again.")); break;
        default: reject(new Error("Unable to detect your location."));
      }
    },
    { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
  );
});

export interface DashboardData {
  available_donors: number;
  active_centers: number;
  pending_requests: number;
  total_inventory_units: number;
  inventory_by_blood_group: Record<string, number>;
}

export interface InventoryItem {
  id: number; center_id: number; center_name: string; city: string;
  blood_group: string; units: number; status: string; updated_at: string;
}

export interface Center {
  id: number;
  name: string;
  address: string;
  city: string;
  phone: string;
  opening_hours: string;
  latitude: number | null;
  longitude: number | null;
  active: boolean;
  location_verified: boolean;
  location_source: string | null;
}

export interface NearbyCenter extends Center { distance_km: number; }

export interface DonorInput {
  full_name: string; email: string; phone: string; blood_group: string;
  city: string; age: number; latitude?: number | null; longitude?: number | null;
}

export interface NearbyDonor {
  id: number; full_name: string; blood_group: string; city: string; distance_km: number;
}

export interface BloodRequestInput {
  patient_name: string; blood_group: string; units: number; hospital: string;
  city: string; contact_phone: string;
  urgency: "normal" | "urgent" | "critical";
  notes?: string; latitude?: number | null; longitude?: number | null;
}

export const getDashboard = (city?: string) => apiRequest<DashboardData>(`/dashboard${city ? `?city=${encodeURIComponent(city)}` : ""}`);
export const getInventory = (city?: string) => apiRequest<InventoryItem[]>(`/inventory${city ? `?city=${encodeURIComponent(city)}` : ""}`);
export const getCenters = (city?: string) => apiRequest<Center[]>(`/centers${city ? `?city=${encodeURIComponent(city)}` : ""}`);
export const registerDonor = (data: DonorInput) => apiRequest("/donors", { method: "POST", body: JSON.stringify(data) });
export const submitBloodRequest = (data: BloodRequestInput) => apiRequest("/requests", { method: "POST", body: JSON.stringify(data) });

export const getNearbyDonors = (location: GPSLocation, radiusKm = 10, bloodGroup?: string) => {
  const params = new URLSearchParams({ latitude: String(location.latitude), longitude: String(location.longitude), radius_km: String(radiusKm) });
  if (bloodGroup) params.set("blood_group", bloodGroup);
  return apiRequest<NearbyDonor[]>(`/donors/nearby?${params.toString()}`);
};

// Retained for compatibility with any other existing screen using the backend endpoint.
export const getNearbyCenters = (location: GPSLocation, radiusKm = 10) => {
  const params = new URLSearchParams({ latitude: String(location.latitude), longitude: String(location.longitude), radius_km: String(radiusKm) });
  return apiRequest<NearbyCenter[]>(`/centers/nearby?${params.toString()}`);
};

export const getNearbyDonorsForRequest = (requestId: number, radiusKm = 10) => {
  const params = new URLSearchParams({ radius_km: String(radiusKm) });
  return apiRequest<NearbyDonor[]>(`/requests/${requestId}/nearby-donors?${params.toString()}`);
};
