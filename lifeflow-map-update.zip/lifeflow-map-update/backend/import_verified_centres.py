"""Import verified Bengaluru blood-centre directory records without deleting history.

Coordinates are populated only where an OpenStreetMap blood-bank feature was verified.
Unknown coordinates remain NULL and are never used for map pins or distance calculations.
"""
from app.database import SessionLocal
from app import models as m

CENTRES = [
    {
        "name": "Bangalore Medical Services Trust (Rotary Bangalore-TTK Blood Bank)",
        "address": "New Thippasandra Main Road, HAL 3rd Stage, Bengaluru, Karnataka 560075",
        "phone": "+91 99001 53000 / +91 99001 60000",
        "latitude": None, "longitude": None, "location_verified": False,
        "location_source": "https://www.bmstindia.org/contact-us/",
    },
    {
        "name": "Indian Red Cross Society - Karnataka Blood Centre",
        "address": "26, Red Cross Bhavan, 1st Floor, Race Course Road, Bengaluru, Karnataka 560001",
        "phone": "080-22268435",
        "latitude": None, "longitude": None, "location_verified": False,
        "location_source": "https://redcrosskarnataka.org/contact-us/",
    },
    {
        "name": "Rashtrotthana Blood Centre",
        "address": "#7, Smt Subhadraben Jayantilal Nagardas Shah (Jain) Bhavan, Gavipuram Guttahalli, Kempegowda Nagar, Bengaluru, Karnataka 560004",
        "phone": "080-26608870 / 080-29747870",
        "latitude": None, "longitude": None, "location_verified": False,
        "location_source": "https://bloodcentre.rashtrotthana.org/contact/",
    },
    {
        "name": "Victoria Hospital Blood Bank",
        "address": "Victoria Hospital campus, New Tharagupet, Bengaluru, Karnataka 560002",
        "phone": "080-26700001",
        "latitude": 12.96355, "longitude": 77.57367, "location_verified": True,
        "location_source": "OpenStreetMap node 6882713299; https://mapcarta.com/N6882713299",
    },
    {
        "name": "Yelahanka Lions Blood Bank",
        "address": "CA Site #9D, Lions Seva Bhavana, 8th A Cross, 16th A Main Road, Yelahanka New Town, Bengaluru, Karnataka 560064",
        "phone": "+91 76187 99131",
        "latitude": None, "longitude": None, "location_verified": False,
        "location_source": "Business directory listing; verify coordinates with the centre before mapping",
    },
    {
        "name": "Jeevaraksha Voluntary Blood Bank",
        "address": "29-31, Cunningham Road, Vasanth Nagar, Bengaluru, Karnataka 560001",
        "phone": "+91 99007 77791",
        "latitude": None, "longitude": None, "location_verified": False,
        "location_source": "Business directory listing; verify coordinates with the centre before mapping",
    },
]

PLACEHOLDERS = {
    "city general hospital",
    "red cross donation center",
    "st. mary's medical center",
}

db = SessionLocal()
try:
    # Keep these rows and their IDs so existing foreign-key history is not broken.
    for center in db.query(m.Center).all():
        if center.name.strip().lower() in PLACEHOLDERS:
            # The bundled seed.py created fictional stock for these placeholder centres.
            # Remove only those demo inventory rows; retain centre IDs and all donor/history records.
            db.query(m.Inventory).filter(m.Inventory.center_id == center.id).delete(synchronize_session=False)
            center.active = False

    for item in CENTRES:
        center = db.query(m.Center).filter(m.Center.name == item["name"]).first()
        if center is None:
            center = m.Center(name=item["name"], city="Bengaluru", opening_hours="Contact centre to confirm", active=True)
            db.add(center)
        for key, value in item.items():
            setattr(center, key, value)
        center.city = "Bengaluru"
        center.opening_hours = "Contact centre to confirm"
        center.active = True

    db.commit()
    print("Centre directory imported successfully.")
    print("Existing placeholder rows were deactivated, not deleted.")
    print("Only Victoria Hospital has a verified map coordinate in this import.")
finally:
    db.close()
